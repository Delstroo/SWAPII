import UIKit

struct Person: Decodable {
    let name: String
    let homeworld: String
    let films: [URL]
    
}

struct Films: Decodable {
    let title: String
    let release_date: String
}

class SwapiService {
    
    static private let baseURL = URL(string: "https://swapi.dev/api/people/")
    
    static func fetchPerson(id: Int, completion: @escaping (Person?) -> Void) {
        
        //https://swapi.dev/api/people/
        
        //Prepare URL
        guard let baseURL = baseURL else { return }
        print("made it here 1")
        let finalURL = baseURL.appendingPathComponent("\(id)")
        print(finalURL)
        //Contact server
        URLSession.shared.dataTask(with: finalURL) { (data, _, error) in
            
            
            
            
            //Handle errors
            if let error = error {
                print("Error in \(#function) : \(error.localizedDescription) \n--\n \(error)")
                return completion(nil)
            }
            
            
            //Check for data
            guard let data = data else { return completion(nil) }
            
            
            //Decode Person from JSON
            do {
                let person = try JSONDecoder().decode(Person.self, from: data)
                print("made it here 2")
                return completion(person)
            } catch {
                print("Error in \(#function) : \(error.localizedDescription) \n----\n \(error)")
                return completion(nil)
            }
        }.resume()
    }
    
    static func fetchFilm(url: URL?, completion: @escaping (Films?) -> Void) {
        guard let finalURL = url else { return completion(nil) }
        
        //Contact server
        URLSession.shared.dataTask(with: finalURL) { (data, _, error) in
            
            
            //Handle errors
            if let error = error {
                print("Error in \(#function) :  \(error.localizedDescription) \n---\n \(error)")
                return completion(nil)
            }
            //Check for data
            guard let data = data else { return completion(nil) }
            
            
            //Decode Film from JSON
            do {
                let films = try JSONDecoder().decode(Films.self, from: data)
                return completion(films)
            } catch {
                print("Error in \(#function) : \(error.localizedDescription) \n----\n \(error)")
                return completion(nil)
            }
        }.resume()
    }
}
func fetchFilm(url: URL) {
    SwapiService.fetchFilm(url: url) { film in
        if let film = film {
            print(film)
            
        }
    }
}
SwapiService.fetchPerson(id: 83) { person in
    if let person = person {
        print(person)
        for film in person.films {
            fetchFilm(url: film)
        }
        
    }
}

//fetchFilm(url: URL( string:"https://swapi.dev/api/films/1/")!)


